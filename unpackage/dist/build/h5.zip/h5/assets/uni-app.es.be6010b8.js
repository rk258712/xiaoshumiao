import{a2 as r}from"./index-074facd1.js";function n(n,o){return r(n)?o:n}export{n as r};
