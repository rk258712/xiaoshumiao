import{a2 as r}from"./index-dc4240aa.js";function n(n,o){return r(n)?o:n}export{n as r};
